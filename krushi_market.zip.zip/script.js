/**
 * ============================================================================
 * VIJAYASHRI AGRO MART — ENTERPRISE JAVASCRIPT ENGINE
 * Modern Agricultural Machinery Discovery, Cart & Lead-Routing Engine
 * ============================================================================
 */

'use strict';

/**
 * ----------------------------------------------------------------------------
 * 1. CENTRAL CONFIGURATION & AUTHENTIC CONTACT DATA
 * ----------------------------------------------------------------------------
 */
const CONFIG = {
  businessName: 'Vijayashri Agro Mart',
  marathiName: 'विजयश्री ॲग्रो मार्ट',
  tagline: 'शेतकऱ्यांच्या हक्काचे ठिकाण',
  officialLocation: 'Nachane, Ratnagiri, Maharashtra - 415639',
  email: 'kunal.5786@gmail.com',
  officialMobile: '9975726256',
  udyamRegistration: 'UDYAM-MH-28-0001865',
  
  // Central WhatsApp number for enquiries and order routing
  whatsappNumber: '919975726256',
  upiId: '9975726256@okbizaxis',
  upiMerchantName: 'Vijayashri Agro Mart',
  tokenBookingAmount: 1000,
  
  // Alternate marketing phone numbers found on authentic creatives
  creativePhoneNumbers: [
    '8369314833',
    '9975726256',
    '9423292359',
    '8329074990',
    '7758018704'
  ],

  // LocalStorage Keys
  storageKeys: {
    cart: 'vijayashri_agro_cart',
    orders: 'vijayashri_agro_orders'
  }
};

/**
 * ----------------------------------------------------------------------------
 * 2. AUTHENTIC PRODUCT CATALOG DATA
 * ----------------------------------------------------------------------------
 */
const PRODUCT_CATALOG = [
  {
    id: 'stihl-fs3001',
    category: 'stihl',
    brand: 'STIHL',
    name: 'STIHL FS 3001',
    marathiName: 'STIHL FS 3001 ब्रश कटर',
    tagline: 'हलके वजन आणि सुलभ वापर (Lightweight & Handy)',
    image: 'assets/generated-products/stihl-fs3001-card.webp',
    gallery: [
      'assets/generated-products/stihl-fs3001-detail.webp',
      'assets/generated-products/stihl-fs3001-hero-desktop.webp',
      'assets/images/creative-stihl.jpg'
    ],
    price: null,
    stock: null,
    specifications: {
      'Displacement (cc)': '25.4',
      'Engine Power (HP)': '1.3',
      'Engine Type': '2 stroke',
      'Fuel': 'Petrol',
      'Starting System': 'Manual',
      'Weight (kg)': '5.6'
    },
    features: [
      'कमी इंधन खपत जास्त कामगिरी',
      'हलके व मजबूत डिझाईन',
      'सुलभ स्टार्ट आणि ऑपरेशन',
      'STIHL ची जागतिक गुणवत्ता'
    ],
    applications: [
      'बागेतील व फळबागेतील हलके गवत कापणे',
      'बांधावरील नियमित स्वच्छता',
      'लहान शेतजमीन देखभाल'
    ],
    source: 'Supplied STIHL creative'
  },
  {
    id: 'stihl-fs230',
    category: 'stihl',
    brand: 'STIHL',
    name: 'STIHL FS 230',
    marathiName: 'STIHL FS 230 ब्रश कटर',
    tagline: 'शक्तिशाली इंजिन आणि उच्च कार्यक्षमता (High Power)',
    image: 'assets/generated-products/stihl-fs230-card.webp',
    gallery: [
      'assets/generated-products/stihl-fs230-detail.webp',
      'assets/images/stihl-all-lineup.jpg',
      'assets/images/creative-stihl.jpg'
    ],
    price: null,
    stock: null,
    specifications: {
      'Displacement (cc)': '40.2',
      'Engine Power (HP)': '2.07',
      'Engine Type': '2 stroke',
      'Fuel': 'Petrol',
      'Starting System': 'Manual',
      'Weight (kg)': '7.3'
    },
    features: [
      'उच्च कार्यक्षमता दीर्घकाळ टिकणारी',
      'मजबूत ब्लेड व जास्त टिकाऊपणा',
      'कठीण गवतासाठी शक्तिशाली आउटपुट',
      'सुलभ सर्व्हिस व पार्ट्स उपलब्ध'
    ],
    applications: [
      'शेतातील अवजड गवत कापणे',
      'ऊस व मैदानी पिकांची स्वच्छता',
      'मोठ्या प्रमाणातील शेती देखभाल'
    ],
    source: 'Supplied STIHL creative'
  },
  {
    id: 'stihl-fs120',
    category: 'stihl',
    brand: 'STIHL',
    name: 'STIHL FS 120',
    marathiName: 'STIHL FS 120 ब्रश कटर',
    tagline: 'संतुलित कामगिरी आणि टिकाऊपणा (Balanced Performance)',
    image: 'assets/generated-products/stihl-fs120-card.webp',
    gallery: [
      'assets/generated-products/stihl-fs120-detail.webp',
      'assets/images/stihl-all-lineup.jpg',
      'assets/images/creative-stihl.jpg'
    ],
    price: null,
    stock: null,
    specifications: {
      'Displacement (cc)': '30.8',
      'Engine Power (HP)': '1.8',
      'Engine Type': '2 stroke',
      'Fuel': 'Petrol',
      'Starting System': 'Manual',
      'Weight (kg)': '6.3'
    },
    features: [
      'कमी कंपन तंत्रज्ञान (Low Vibration)',
      'आरामदायक हँडल्स व नियंत्रण',
      'इंधन कार्यक्षम 2-स्ट्रोक इंजिन',
      'नियमित शेतकामांसाठी परिपूर्ण'
    ],
    applications: [
      'बागायती व फळबाग सफाईसाठी आदर्श',
      'शेतीमधील मध्यम ते जड तण कापणे',
      'नारळ, सुपारी बागांची स्वच्छता'
    ],
    source: 'Supplied STIHL creative'
  },
  {
    id: 'stihl-fs250',
    category: 'stihl',
    brand: 'STIHL',
    name: 'STIHL FS 250',
    marathiName: 'STIHL FS 250 हेवी ड्युटी ब्रश कटर',
    tagline: 'कमाल शक्ती आणि व्यावसायिक वापर (Maximum Power)',
    image: 'assets/generated-products/stihl-fs250-card.webp',
    gallery: [
      'assets/generated-products/stihl-fs250-detail.webp',
      'assets/generated-products/stihl-fs250-use-case.webp',
      'assets/images/creative-stihl.jpg'
    ],
    price: null,
    stock: null,
    specifications: {
      'Displacement (cc)': '40.2',
      'Engine Power (HP)': '2.14',
      'Engine Type': '2 stroke',
      'Fuel': 'Petrol',
      'Starting System': 'Manual',
      'Weight (kg)': '6.3'
    },
    features: [
      '२.१४ HP ची सर्वोच्च ताकद',
      'कमी वजनात जास्त पॉवर रेशो (6.3 kg)',
      'हेवी-ड्युटी व्यावसायिक शेती कामांसाठी',
      'अखंड वापरासाठी मजबूत डिझाईन'
    ],
    applications: [
      'व्यावसायिक शेती व कंत्राटी गवत कापणी',
      'अवजड झाडे, झुडपे व काटेरी तण साफ करणे',
      'डोंगरउतारावरील व दुर्गम शेतातील कामे'
    ],
    source: 'Supplied STIHL creative'
  },
  {
    id: 'really-cr-r35-s',
    category: 'crop-reaper',
    brand: 'Really',
    name: 'Really CR-R35-S Baffle Crop Reaper',
    marathiName: 'Really CR-R35-S बॅफल क्रॉप रिपर',
    tagline: 'Work Faster. Cut Better. (FMTTI Approved)',
    image: 'assets/generated-products/really-cr-r35-s-card.webp',
    gallery: [
      'assets/generated-products/really-cr-r35-s-detail.webp',
      'assets/generated-products/really-cr-r35-s-use-case.webp',
      'assets/images/creative-really-reaper.jpg'
    ],
    price: null,
    stock: null,
    specifications: {
      'Engine Model': '4 Stroke',
      'Engine Power': '35CC / 1 KW',
      'Fuel': 'Petrol',
      'Carry Type': 'Sidepack',
      'Certification': 'FMTTI Approved'
    },
    accessories: [
      { name: 'Trimmer Head', img: 'assets/images/acc-trimmer-head.jpg' },
      { name: '2MM 2T Blade', img: 'assets/images/acc-2t-blade.jpg' },
      { name: '80T TCT Blade', img: 'assets/images/acc-80t-blade.jpg' },
      { name: 'Paddy Harvester', img: 'assets/images/acc-paddy-harvester.jpg' }
    ],
    features: [
      'High Power & Efficiency',
      'Low Vibration Technology',
      'Ergonomic Design',
      'Easy Start System',
      'Durable & Long Lasting'
    ],
    applications: [
      'Grass Cutting (गवत कटिंग)',
      'Paddy Cutting (भात कटिंग)',
      'Farm Maintenance (शेती देखभाल)',
      'Orchard Cleaning (फळबाग स्वच्छता)'
    ],
    source: 'Supplied Really creative'
  },
  {
    id: 'elemax-generator',
    category: 'generators',
    brand: 'ELEMAX',
    name: 'ELEMAX Generator',
    marathiName: 'ELEMAX जनरेटर',
    tagline: 'Powered by KOHLER Diesel',
    image: 'assets/generated-products/elemax-generator-card.webp',
    gallery: [
      'assets/generated-products/elemax-generator-detail.webp',
      'assets/images/creative-generators.jpg'
    ],
    price: null,
    stock: null,
    specifications: {
      'Engine': 'Powered by KOHLER Diesel',
      'Fuel Type': 'Diesel',
      'Build': 'Heavy Duty Sound Proof Canopy'
    },
    features: [
      'KOHLER डिझेल इंजिनची ताकद',
      'शेतीतील पंप व वीज उपकरणांसाठी उपयुक्त',
      'टिकाऊ आणि मजबूत व्हील्स बॉडी'
    ],
    applications: [
      'शेतातील वीज पुरवठा',
      'सिंचन पंप व मोटार चालवणे',
      'घरगुती व कृषी आणीबाणी वीज'
    ],
    source: 'Supplied generator creative'
  },
  {
    id: 'lighton-generator',
    category: 'generators',
    brand: 'LIGHTON',
    name: 'LIGHTON SilentPRO Generator',
    marathiName: 'LIGHTON SilentPRO जनरेटर',
    tagline: 'SilentPRO LT-9000 Series',
    image: 'assets/generated-products/lighton-generator-card.webp',
    gallery: [
      'assets/generated-products/lighton-generator-detail.webp',
      'assets/images/creative-generators.jpg'
    ],
    price: null,
    stock: null,
    specifications: {
      'Model Series': 'SilentPRO LT-9000',
      'Type': 'Compact Silent Generator'
    },
    features: [
      'कमी आवाज (Silent Operation)',
      'पोर्टेबल व हाताळण्यास सोपे',
      'सुलभ स्टार्ट आणि कमी मेंटेनन्स'
    ],
    applications: [
      'शेती फार्महाऊस वीज',
      'कृषी प्रकाशयोजना व स्प्रेअर चार्जिंग',
      'दुकान व शेती कार्यालय'
    ],
    source: 'Supplied generator creative'
  },
  {
    id: 'pelican-generator',
    category: 'generators',
    brand: 'PELICAN',
    name: 'PELICAN Generator',
    marathiName: 'PELICAN पॉवर जनरेटर',
    tagline: 'PELICAN W900APL Series',
    image: 'assets/generated-products/pelican-generator-card.webp',
    gallery: [
      'assets/generated-products/pelican-generator-detail.webp',
      'assets/images/creative-generators.jpg'
    ],
    price: null,
    stock: null,
    specifications: {
      'Model Series': 'PELICAN W900APL',
      'Design': 'Open Frame Heavy Duty'
    },
    features: [
      'मजबूत पाईप फ्रेम प्रोटेक्शन',
      'शेतातील खडतर वातावरणासाठी सक्षम',
      'सुलभ नियंत्रण पॅनेल'
    ],
    applications: [
      'वेल्डिंग व शेती अवजारे चालवणे',
      'शेततळे व बोरवेल पंप वापर',
      'बांधकाम व कृषी कामे'
    ],
    source: 'Supplied generator creative'
  }
];

/**
 * ----------------------------------------------------------------------------
 * 3. APPLICATION STATE
 * ----------------------------------------------------------------------------
 */
const AppState = {
  currentFilter: 'all',
  searchQuery: '',
  cart: [],
  activeModalProduct: null,
  activeModalQty: 1
};

/**
 * ----------------------------------------------------------------------------
 * 4. INITIALIZATION & LIFECYCLE
 * ----------------------------------------------------------------------------
 */
document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

function initApp() {
  loadCart();
  updateFilterPillCounts();
  renderProducts();
  setupEventListeners();
  updateCartBadge();
  initHeroThumbnailSwitcher();
  initHeaderScrollEffect();
  initScrollSpy();
  initMobileComparator();
}

/**
 * ----------------------------------------------------------------------------
 * 5. EVENT LISTENERS SETUP
 * ----------------------------------------------------------------------------
 */
function setupEventListeners() {
  // Mobile Nav Toggle
  const mobileToggle = document.getElementById('mobileNavToggle');
  const mainNav = document.getElementById('mainNav');
  if (mobileToggle && mainNav) {
    mobileToggle.addEventListener('click', () => {
      const isExpanded = mainNav.classList.toggle('mobile-active');
      mobileToggle.setAttribute('aria-expanded', isExpanded ? 'true' : 'false');
    });
  }

  // Smooth scroll links & close mobile menu
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const href = this.getAttribute('href');
      if (href.startsWith('#legal-')) return;
      
      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        if (mainNav) {
          mainNav.classList.remove('mobile-active');
          if (mobileToggle) mobileToggle.setAttribute('aria-expanded', 'false');
        }
        
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  // Category Filter Pills
  document.querySelectorAll('.filter-pill').forEach(pill => {
    pill.addEventListener('click', (e) => {
      const filter = e.currentTarget.getAttribute('data-filter');
      filterProducts(filter);
    });
  });

  // Department / Category Cards Click
  document.querySelectorAll('.dept-panel-card').forEach(card => {
    const handleCategoryClick = () => {
      const filter = card.getAttribute('data-filter');
      filterProducts(filter);
      const productSection = document.getElementById('products');
      if (productSection) {
        productSection.scrollIntoView({ behavior: 'smooth' });
      }
    };

    card.addEventListener('click', handleCategoryClick);
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        handleCategoryClick();
      }
    });
  });

  // Search Input & Clear
  const searchInput = document.getElementById('catalogSearchInput');
  const searchClear = document.getElementById('searchClearBtn');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      AppState.searchQuery = e.target.value.trim().toLowerCase();
      if (searchClear) {
        searchClear.style.display = AppState.searchQuery ? 'block' : 'none';
      }
      renderProducts();
    });
  }

  if (searchClear) {
    searchClear.addEventListener('click', () => {
      resetCatalogSearch();
    });
  }

  // Cart Drawer Triggers & Close
  const cartTriggerBtn = document.getElementById('cartTriggerBtn');
  const cartDrawerCloseBtn = document.getElementById('cartDrawerCloseBtn');
  const cartDrawerBackdrop = document.getElementById('cartDrawerBackdrop');

  if (cartTriggerBtn) cartTriggerBtn.addEventListener('click', openCart);
  if (cartDrawerCloseBtn) cartDrawerCloseBtn.addEventListener('click', closeCart);
  if (cartDrawerBackdrop) {
    cartDrawerBackdrop.addEventListener('click', (e) => {
      if (e.target === cartDrawerBackdrop) closeCart();
    });
  }

  // Product Modal Close
  const productModalCloseBtn = document.getElementById('productModalCloseBtn');
  const productModalBackdrop = document.getElementById('productModalBackdrop');
  if (productModalCloseBtn) productModalCloseBtn.addEventListener('click', closeProductModal);
  if (productModalBackdrop) {
    productModalBackdrop.addEventListener('click', (e) => {
      if (e.target === productModalBackdrop) closeProductModal();
    });
  }

  // Checkout Modal Close
  const checkoutModalCloseBtn = document.getElementById('checkoutModalCloseBtn');
  const checkoutModalBackdrop = document.getElementById('checkoutModalBackdrop');
  if (checkoutModalCloseBtn) checkoutModalCloseBtn.addEventListener('click', closeCheckout);
  if (checkoutModalBackdrop) {
    checkoutModalBackdrop.addEventListener('click', (e) => {
      if (e.target === checkoutModalBackdrop) closeCheckout();
    });
  }

  // Legal Modal Close
  const legalModalCloseBtn = document.getElementById('legalModalCloseBtn');
  const legalModalBackdrop = document.getElementById('legalModalBackdrop');
  if (legalModalCloseBtn) legalModalCloseBtn.addEventListener('click', closeLegalModal);
  if (legalModalBackdrop) {
    legalModalBackdrop.addEventListener('click', (e) => {
      if (e.target === legalModalBackdrop) closeLegalModal();
    });
  }

  // Escape key global listener
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeProductModal();
      closeCart();
      closeCheckout();
      closeOrderSuccessModal();
      closeLegalModal();
    }
  });

  // Forms Submissions
  // Payment Mode Radio Switcher
  document.querySelectorAll('input[name="paymentMode"]').forEach(radio => {
    radio.addEventListener('change', handlePaymentModeChange);
  });

  const checkoutForm = document.getElementById('checkoutForm');
  if (checkoutForm) checkoutForm.addEventListener('submit', handleCheckoutSubmit);

  const quickEnquiryForm = document.getElementById('quickEnquiryForm');
  if (quickEnquiryForm) quickEnquiryForm.addEventListener('submit', handleQuickEnquirySubmit);
}

/**
 * ----------------------------------------------------------------------------
 * 6. DYNAMIC FILTER COUNTS & SEARCH
 * ----------------------------------------------------------------------------
 */
function updateFilterPillCounts() {
  const countAll = document.getElementById('countAll');
  const countStihl = document.getElementById('countStihl');
  const countReaper = document.getElementById('countReaper');
  const countGenerators = document.getElementById('countGenerators');

  if (countAll) countAll.textContent = PRODUCT_CATALOG.length;
  if (countStihl) countStihl.textContent = PRODUCT_CATALOG.filter(p => p.category === 'stihl').length;
  if (countReaper) countReaper.textContent = PRODUCT_CATALOG.filter(p => p.category === 'crop-reaper').length;
  if (countGenerators) countGenerators.textContent = PRODUCT_CATALOG.filter(p => p.category === 'generators').length;
}

function resetCatalogSearch() {
  const searchInput = document.getElementById('catalogSearchInput');
  const searchClear = document.getElementById('searchClearBtn');
  if (searchInput) searchInput.value = '';
  if (searchClear) searchClear.style.display = 'none';
  AppState.searchQuery = '';
  AppState.currentFilter = 'all';
  
  document.querySelectorAll('.filter-pill').forEach(pill => {
    pill.classList.toggle('active', pill.getAttribute('data-filter') === 'all');
    pill.setAttribute('aria-selected', pill.getAttribute('data-filter') === 'all' ? 'true' : 'false');
  });

  renderProducts();
}

/**
 * ----------------------------------------------------------------------------
 * 7. PRODUCT RENDERING & STREAMLINED CARDS
 * ----------------------------------------------------------------------------
 */
function renderProducts() {
  const grid = document.getElementById('productGrid');
  const emptyState = document.getElementById('catalogEmptyState');
  if (!grid) return;

  // Filter by category
  let list = AppState.currentFilter === 'all'
    ? PRODUCT_CATALOG
    : PRODUCT_CATALOG.filter(p => p.category === AppState.currentFilter);

  // Filter by search query
  if (AppState.searchQuery) {
    const q = AppState.searchQuery;
    list = list.filter(p => {
      const matchName = p.name.toLowerCase().includes(q);
      const matchMarathi = p.marathiName && p.marathiName.toLowerCase().includes(q);
      const matchBrand = p.brand.toLowerCase().includes(q);
      const matchTag = p.tagline && p.tagline.toLowerCase().includes(q);
      
      let matchSpecs = false;
      if (p.specifications) {
        matchSpecs = Object.entries(p.specifications).some(([k, v]) => 
          k.toLowerCase().includes(q) || String(v).toLowerCase().includes(q)
        );
      }

      let matchApps = false;
      if (p.applications) {
        matchApps = p.applications.some(a => a.toLowerCase().includes(q));
      }

      return matchName || matchMarathi || matchBrand || matchTag || matchSpecs || matchApps;
    });
  }

  grid.innerHTML = '';

  if (list.length === 0) {
    grid.style.display = 'none';
    if (emptyState) emptyState.style.display = 'flex';
  } else {
    grid.style.display = 'grid';
    if (emptyState) emptyState.style.display = 'none';
    list.forEach(product => {
      const card = createProductCardElement(product);
      grid.appendChild(card);
    });
  }
}

function createProductCardElement(product) {
  const card = document.createElement('div');
  card.className = 'product-card';
  card.setAttribute('data-id', product.id);

  // Top 3 specs badges
  let specBadgesHtml = '';
  if (product.specifications) {
    const entries = Object.entries(product.specifications).slice(0, 3);
    entries.forEach(([key, val]) => {
      specBadgesHtml += `<span class="spec-badge">${key}: ${val}</span>`;
    });
  }

  const brandClass = product.brand.toLowerCase().replace(/\s+/g, '-');

  card.innerHTML = `
    <div class="card-top-bar">
      <span class="brand-chip ${brandClass}">${product.brand}</span>
      <button class="card-wa-icon-btn" onclick="enquireProductViaWhatsApp('${product.id}')" title="WhatsApp वर चौकशी" aria-label="Chat on WhatsApp">
        <svg class="icon-sm icon-wa" viewBox="0 0 24 24" fill="currentColor"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>
      </button>
    </div>
    
    <div class="product-image-area" onclick="openProductModal('${product.id}')" title="तपशील पाहण्यासाठी क्लिक करा">
      <div class="card-grounding-plate" aria-hidden="true"></div>
      <img src="${product.image}" alt="${product.name}" width="280" height="280" loading="lazy">
    </div>

    <div class="product-card-body">
      <h3 class="product-card-title">${product.name}</h3>
      <p class="product-tagline">${product.tagline || ''}</p>
      
      <div class="product-spec-row">
        ${specBadgesHtml}
      </div>

      <div class="product-price-status">
        <span style="font-size: var(--text-micro); color: var(--color-muted);">किंमत:</span>
        <span class="badge-enquiry-pill">चौकशीवर उपलब्ध</span>
      </div>

      <!-- Streamlined 2-Button Action Flow -->
      <div class="card-actions-grid">
        <button class="btn btn-outline-card btn-sm" onclick="openProductModal('${product.id}')">
          <span>तपशील पहा</span>
        </button>
        <button class="btn btn-primary btn-sm" onclick="addToCart('${product.id}')">
          <span>कार्टमध्ये जोडा</span>
        </button>
      </div>
    </div>
  `;

  return card;
}

function filterProducts(category) {
  AppState.currentFilter = category;

  document.querySelectorAll('.filter-pill').forEach(pill => {
    const isActive = pill.getAttribute('data-filter') === category;
    pill.classList.toggle('active', isActive);
    pill.setAttribute('aria-selected', isActive ? 'true' : 'false');
  });

  renderProducts();
}

/**
 * ----------------------------------------------------------------------------
 * 8. PRODUCT DETAIL MODAL v2 (1000–1100px Desktop)
 * ----------------------------------------------------------------------------
 */
function openProductModal(productId) {
  const product = PRODUCT_CATALOG.find(p => p.id === productId);
  if (!product) return;

  AppState.activeModalProduct = product;
  AppState.activeModalQty = 1;

  const modalBody = document.getElementById('productModalBody');
  const modalBackdrop = document.getElementById('productModalBackdrop');

  if (!modalBody || !modalBackdrop) return;

  // Specs table
  let specsRows = '';
  if (product.specifications) {
    Object.entries(product.specifications).forEach(([key, val]) => {
      specsRows += `
        <tr>
          <td>${key}</td>
          <td><strong>${val}</strong></td>
        </tr>
      `;
    });
  }

  // Accessories (Really reaper)
  let accessoriesHtml = '';
  if (product.accessories && product.accessories.length > 0) {
    accessoriesHtml = `
      <div style="margin-top: var(--space-xs);">
        <strong style="font-size: var(--text-xs); color: var(--color-deep-forest); display: block; margin-bottom: 4px;">उपलब्ध अ‍ॅक्सेसरीज (Included Attachments):</strong>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(90px, 1fr)); gap: 6px;">
          ${product.accessories.map(acc => `
            <div style="background-color: var(--color-warm-surface); border: 1px solid var(--color-border); border-radius: 6px; padding: 4px; text-align: center;">
              <img src="${acc.img}" alt="${acc.name}" style="height: 44px; width: 100%; object-fit: contain; background: white; border-radius: 4px;">
              <span style="font-size: 0.68rem; font-weight: 600; display: block; margin-top: 2px;">${acc.name}</span>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  // Applications
  let appsHtml = '';
  if (product.applications && product.applications.length > 0) {
    appsHtml = `
      <div style="margin-top: var(--space-xs);">
        <strong style="font-size: var(--text-xs); color: var(--color-deep-forest); display: block; margin-bottom: 2px;">उपयुक्तता (Applications):</strong>
        <ul style="padding-left: 16px; list-style-type: disc; font-size: var(--text-xs); color: var(--color-body); line-height: 1.45;">
          ${product.applications.map(app => `<li>${app}</li>`).join('')}
        </ul>
      </div>
    `;
  }

  // Gallery Thumbnails
  let thumbsHtml = '';
  if (product.gallery && product.gallery.length > 1) {
    thumbsHtml = `
      <div class="modal-thumbs-row">
        ${product.gallery.map((imgSrc, idx) => `
          <img src="${imgSrc}" class="modal-thumb-btn ${idx === 0 ? 'active' : ''}" onclick="switchModalGalleryImage('${imgSrc}', this)" alt="${product.name}">
        `).join('')}
      </div>
    `;
  }

  modalBody.innerHTML = `
    <div class="modal-product-split">
      <!-- Gallery Left -->
      <div class="modal-gallery-area">
        <div class="modal-main-img-wrap">
          <img id="modalMainImg" src="${product.image}" alt="${product.name}">
        </div>
        ${thumbsHtml}
      </div>

      <!-- Technical Info Right -->
      <div class="modal-info-area">
        <div>
          <span class="modal-brand-label">${product.brand}</span>
          <h2 class="modal-product-heading" id="modalProductTitle">${product.name}</h2>
          <p style="font-size: var(--text-xs); color: var(--color-body);">${product.marathiName || ''}</p>
        </div>

        <div>
          <span class="badge-enquiry-pill" style="font-size: var(--text-xs); padding: 4px 12px;">किंमत: चौकशीवर उपलब्ध (Price on Enquiry)</span>
        </div>

        <div>
          <strong style="font-size: var(--text-xs); color: var(--color-deep-forest);">तांत्रिक तपशील (Technical Specifications):</strong>
          <table class="modal-specs-table-view">
            <tbody>
              ${specsRows}
            </tbody>
          </table>
        </div>

        ${accessoriesHtml}
        ${appsHtml}

        <div class="modal-sticky-action-row">
          <div class="qty-stepper">
            <button class="qty-step-btn" onclick="adjustModalQty(-1)" aria-label="Decrease Quantity">-</button>
            <span class="qty-step-value" id="modalQtyDisplay">1</span>
            <button class="qty-step-btn" onclick="adjustModalQty(1)" aria-label="Increase Quantity">+</button>
          </div>

          <button class="btn btn-primary" onclick="addModalProductToCart()">
            <svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
            <span>कार्टमध्ये जोडा</span>
          </button>

          <button class="btn btn-whatsapp-btn" onclick="enquireProductViaWhatsApp('${product.id}')">
            <svg class="icon-sm icon-wa" viewBox="0 0 24 24" fill="currentColor"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z"/></svg>
            <span>WhatsApp वर थेट चौकशी</span>
          </button>
        </div>
      </div>
    </div>
  `;

  modalBackdrop.classList.add('active');
  modalBackdrop.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
}

function closeProductModal() {
  const modalBackdrop = document.getElementById('productModalBackdrop');
  if (modalBackdrop) {
    modalBackdrop.classList.remove('active');
    modalBackdrop.setAttribute('aria-hidden', 'true');
  }
  document.body.style.overflow = '';
}

function switchModalGalleryImage(imgSrc, thumbEl) {
  const mainImg = document.getElementById('modalMainImg');
  if (mainImg) mainImg.src = imgSrc;
  document.querySelectorAll('.modal-thumb-btn').forEach(t => t.classList.remove('active'));
  if (thumbEl) thumbEl.classList.add('active');
}

function adjustModalQty(delta) {
  AppState.activeModalQty = Math.max(1, AppState.activeModalQty + delta);
  const qtyDisplay = document.getElementById('modalQtyDisplay');
  if (qtyDisplay) qtyDisplay.textContent = AppState.activeModalQty;
}

function addModalProductToCart() {
  if (!AppState.activeModalProduct) return;
  addToCart(AppState.activeModalProduct.id, AppState.activeModalQty);
  closeProductModal();
}

/**
 * ----------------------------------------------------------------------------
 * 9. HERO PRODUCT SHOWCASE SWITCHER
 * ----------------------------------------------------------------------------
 */
function initHeroThumbnailSwitcher() {
  const thumbCards = document.querySelectorAll('.hero-nav-thumb');
  const mainHeroImg = document.getElementById('heroShowcaseImg');
  const pictureEl = document.getElementById('heroShowcasePicture');
  const modelName = document.getElementById('heroModelName');
  const modelSpec = document.getElementById('heroModelSpec');
  
  if (!mainHeroImg || !thumbCards.length) return;

  thumbCards.forEach(card => {
    card.addEventListener('click', () => {
      thumbCards.forEach(c => {
        c.classList.remove('active');
        c.setAttribute('aria-selected', 'false');
      });
      card.classList.add('active');
      card.setAttribute('aria-selected', 'true');

      const newSrc = card.getAttribute('data-img');
      const newName = card.getAttribute('data-name');
      const newSpec = card.getAttribute('data-spec');

      if (newSrc) {
        mainHeroImg.style.opacity = '0';
        setTimeout(() => {
          mainHeroImg.src = newSrc;
          if (pictureEl) {
            const sources = pictureEl.querySelectorAll('source');
            sources.forEach(src => src.srcset = newSrc);
          }
          if (modelName && newName) modelName.textContent = newName;
          if (modelSpec && newSpec) modelSpec.textContent = newSpec;
          mainHeroImg.style.opacity = '1';
        }, 140);
      }
    });
  });
}

/**
 * ----------------------------------------------------------------------------
 * 10. MOBILE COMPARISON ACCORDION
 * ----------------------------------------------------------------------------
 */
function initMobileComparator() {
  switchMobileComparator('stihl-fs3001');
}

function switchMobileComparator(modelId, btnEl) {
  const card = document.getElementById('mobileComparatorCard');
  const product = PRODUCT_CATALOG.find(p => p.id === modelId);
  if (!card || !product) return;

  document.querySelectorAll('.model-tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  if (btnEl) btnEl.classList.add('active');

  card.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--color-border); padding-bottom: 8px;">
      <div>
        <h4 style="font-size: 1.1rem; font-weight: 800; color: var(--color-deep-forest);">${product.name}</h4>
        <span style="font-size: var(--text-xs); color: var(--color-amber-dark); font-weight: 700;">${product.tagline}</span>
      </div>
      <span class="badge-enquiry-pill">चौकशीवर</span>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; font-size: var(--text-xs); margin: 6px 0;">
      <div style="background: white; padding: 6px 8px; border-radius: 4px; border: 1px solid var(--color-border);">
        <span style="color: var(--color-muted); display: block;">Displacement</span>
        <strong style="color: var(--color-forest);">${product.specifications['Displacement (cc)']} cc</strong>
      </div>
      <div style="background: white; padding: 6px 8px; border-radius: 4px; border: 1px solid var(--color-border);">
        <span style="color: var(--color-muted); display: block;">Engine Power</span>
        <strong style="color: var(--color-amber);">${product.specifications['Engine Power (HP)']} HP</strong>
      </div>
      <div style="background: white; padding: 6px 8px; border-radius: 4px; border: 1px solid var(--color-border);">
        <span style="color: var(--color-muted); display: block;">Weight</span>
        <strong style="color: var(--color-ink);">${product.specifications['Weight (kg)']} kg</strong>
      </div>
      <div style="background: white; padding: 6px 8px; border-radius: 4px; border: 1px solid var(--color-border);">
        <span style="color: var(--color-muted); display: block;">Engine Type</span>
        <strong style="color: var(--color-ink);">${product.specifications['Engine Type']}</strong>
      </div>
    </div>

    <div style="font-size: var(--text-xs); color: var(--color-body);">
      <strong>उपयुक्तता:</strong> ${product.applications ? product.applications[0] : 'शेती कामे'}
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-top: 6px;">
      <button class="btn btn-outline-card btn-sm" onclick="openProductModal('${product.id}')">तपशील पहा</button>
      <button class="btn btn-primary btn-sm" onclick="addToCart('${product.id}')">कार्टमध्ये जोडा</button>
    </div>
  `;
}

/**
 * ----------------------------------------------------------------------------
 * 11. CART MANAGEMENT & PERSISTENCE
 * ----------------------------------------------------------------------------
 */
function addToCart(productId, quantity = 1) {
  const product = PRODUCT_CATALOG.find(p => p.id === productId);
  if (!product) return;

  const existing = AppState.cart.find(item => item.id === productId);
  if (existing) {
    existing.quantity += quantity;
  } else {
    AppState.cart.push({
      id: product.id,
      name: product.name,
      brand: product.brand,
      image: product.image,
      tagline: product.tagline || '',
      quantity: quantity
    });
  }

  saveCart();
  updateCartBadge();
  renderCart();
  showToast(`✓ ${product.name} (${quantity} नग) कार्टमध्ये जोडले!`, 'success');
}

function removeFromCart(productId) {
  AppState.cart = AppState.cart.filter(item => item.id !== productId);
  saveCart();
  updateCartBadge();
  renderCart();
  showToast('आयटम कार्टमधून काढण्यात आला', 'info');
}

function updateQuantity(productId, delta) {
  const item = AppState.cart.find(i => i.id === productId);
  if (!item) return;

  item.quantity += delta;
  if (item.quantity <= 0) {
    removeFromCart(productId);
  } else {
    saveCart();
    updateCartBadge();
    renderCart();
  }
}

function saveCart() {
  try {
    localStorage.setItem(CONFIG.storageKeys.cart, JSON.stringify(AppState.cart));
  } catch (err) {
    console.warn('LocalStorage save error:', err);
  }
}

function loadCart() {
  try {
    const saved = localStorage.getItem(CONFIG.storageKeys.cart);
    if (saved) AppState.cart = JSON.parse(saved);
  } catch (err) {
    AppState.cart = [];
  }
}

function updateCartBadge() {
  const totalCount = AppState.cart.reduce((sum, item) => sum + item.quantity, 0);

  const headerBadge = document.getElementById('cartBadgeCount');
  const mobileBadge = document.getElementById('mobileCartBadge');
  const quickQuoteBadge = document.getElementById('quickQuoteBadge');
  const drawerCount = document.getElementById('drawerCartCount');

  if (headerBadge) headerBadge.textContent = totalCount;
  if (mobileBadge) mobileBadge.textContent = totalCount;
  if (quickQuoteBadge) quickQuoteBadge.textContent = totalCount;
  if (drawerCount) drawerCount.textContent = `${totalCount} आयटम्स`;
}

function renderCart() {
  const drawerBody = document.getElementById('cartDrawerBody');
  const drawerFooter = document.getElementById('cartDrawerFooter');
  const summaryQty = document.getElementById('cartSummaryQuantity');

  if (!drawerBody) return;

  const totalCount = AppState.cart.reduce((sum, item) => sum + item.quantity, 0);

  if (AppState.cart.length === 0) {
    drawerBody.innerHTML = `
      <div class="empty-cart-state">
        <div class="empty-icon-wrap">
          <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
        </div>
        <h4 style="font-weight: 800; color: var(--color-deep-forest);">तुमची कार्ट सध्या रिकामी आहे</h4>
        <p style="font-size: var(--text-xs); color: var(--color-body);">शेतीसाठी लागणारी दर्जेदार उपकरणे पाहण्यासाठी खालील बटणावर क्लिक करा.</p>
        <button class="btn btn-primary btn-sm" onclick="closeCart(); document.getElementById('products').scrollIntoView({behavior: 'smooth'});">
          उत्पादने पहा (Browse Products)
        </button>
      </div>
    `;
    if (drawerFooter) drawerFooter.style.display = 'none';
    return;
  }

  if (drawerFooter) drawerFooter.style.display = 'flex';
  if (summaryQty) summaryQty.textContent = `${totalCount} नग`;

  let itemsHtml = '';
  AppState.cart.forEach(item => {
    itemsHtml += `
      <div class="cart-item-row">
        <img src="${item.image}" alt="${item.name}" class="cart-item-thumb">
        
        <div class="cart-item-details">
          <span class="brand-chip ${item.brand.toLowerCase()}" style="display: inline-block; width: max-content; font-size: 0.65rem;">${item.brand}</span>
          <h4 class="cart-item-name">${item.name}</h4>
          <span style="font-size: 0.72rem; color: var(--color-muted);">चौकशीवर किंमत (On Enquiry)</span>
          
          <div class="cart-item-qty-bar">
            <div class="cart-qty-toggle">
              <button onclick="updateQuantity('${item.id}', -1)" aria-label="Decrease quantity">-</button>
              <span>${item.quantity}</span>
              <button onclick="updateQuantity('${item.id}', 1)" aria-label="Increase quantity">+</button>
            </div>
            <button class="cart-trash-btn" onclick="removeFromCart('${item.id}')" title="काढून टाका">काढा</button>
          </div>
        </div>
      </div>
    `;
  });

  drawerBody.innerHTML = itemsHtml;
}

function openCart() {
  renderCart();
  const drawerBackdrop = document.getElementById('cartDrawerBackdrop');
  if (drawerBackdrop) {
    drawerBackdrop.classList.add('active');
    drawerBackdrop.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }
}

function closeCart() {
  const drawerBackdrop = document.getElementById('cartDrawerBackdrop');
  if (drawerBackdrop) {
    drawerBackdrop.classList.remove('active');
    drawerBackdrop.setAttribute('aria-hidden', 'true');
  }
  document.body.style.overflow = '';
}

/**
 * ----------------------------------------------------------------------------
 * 12. CHECKOUT & ORDER SUBMISSION FLOW
 * ----------------------------------------------------------------------------
 */

/**
 * ----------------------------------------------------------------------------
 * 12a. UPI PAYMENT MANAGEMENT ENGINE
 * ----------------------------------------------------------------------------
 */
function handlePaymentModeChange(e) {
  const selectedMode = e ? e.target.value : (document.querySelector('input[name="paymentMode"]:checked') || {}).value;
  const upiBox = document.getElementById('upiPaymentBox');
  const upiOptionLabel = document.getElementById('upiPaymentOptionLabel');
  const confirmOptionLabel = document.getElementById('payOnConfirmOption') || document.querySelector('.payment-card-option');
  
  document.querySelectorAll('.payment-card-option').forEach(card => {
    const isChecked = card.querySelector('input').checked;
    card.classList.toggle('selected', isChecked);
  });

  if (selectedMode === 'UPI Payment') {
    if (upiBox) upiBox.style.display = 'block';
    updateUpiPaymentDetails();
  } else {
    if (upiBox) upiBox.style.display = 'none';
    const upiErr = document.getElementById('checkoutUpiRefError');
    if (upiErr) upiErr.textContent = '';
  }
}

function updateUpiPaymentDetails() {
  const totalCount = AppState.cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalAmt = Math.max(1000, totalCount * (CONFIG.tokenBookingAmount || 1000));
  
  const amtDisplay = document.getElementById('upiPayAmountDisplay');
  if (amtDisplay) {
    amtDisplay.textContent = `₹${totalAmt.toLocaleString('en-IN')} (टोकन बुकिंग: ${totalCount} उपकरणे)`;
  }

  const upiId = CONFIG.upiId || '9975726256@okbizaxis';
  const upiName = encodeURIComponent(CONFIG.upiMerchantName || 'Vijayashri Agro Mart');
  const note = encodeURIComponent('Booking Vijayashri Agro Mart');
  const upiUrl = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${upiName}&am=${totalAmt}&cu=INR&tn=${note}`;

  const qrImg = document.getElementById('upiQrImage');
  if (qrImg) {
    qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=8&data=${encodeURIComponent(upiUrl)}`;
  }

  const directBtn = document.getElementById('directUpiIntentBtn');
  if (directBtn) {
    directBtn.href = upiUrl;
  }
}

function copyUpiId() {
  const upiId = CONFIG.upiId || '9975726256@okbizaxis';
  const btnText = document.getElementById('copyUpiBtnText');
  
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(upiId).then(() => {
      if (btnText) btnText.textContent = 'Copied! ✓';
      showToast('✓ अधिकृत UPI ID कॉपी केला!', 'success');
      setTimeout(() => { if (btnText) btnText.textContent = 'Copy'; }, 2500);
    }).catch(() => {
      prompt('Copy UPI ID:', upiId);
    });
  } else {
    prompt('Copy UPI ID:', upiId);
  }
}

function openCheckout() {
  if (AppState.cart.length === 0) {
    showToast('कृपया प्रथम कार्टमध्ये उपकरण जोडा.', 'info');
    return;
  }

  closeCart();
  renderCheckoutSummary();
  handlePaymentModeChange();

  const checkoutBackdrop = document.getElementById('checkoutModalBackdrop');
  if (checkoutBackdrop) {
    checkoutBackdrop.classList.add('active');
    checkoutBackdrop.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }
}

function closeCheckout() {
  const checkoutBackdrop = document.getElementById('checkoutModalBackdrop');
  if (checkoutBackdrop) {
    checkoutBackdrop.classList.remove('active');
    checkoutBackdrop.setAttribute('aria-hidden', 'true');
  }
  document.body.style.overflow = '';
}

function renderCheckoutSummary() {
  const summaryList = document.getElementById('checkoutSummaryItems');
  const summaryQty = document.getElementById('checkoutSummaryQty');
  if (!summaryList) return;

  const totalCount = AppState.cart.reduce((sum, item) => sum + item.quantity, 0);
  if (summaryQty) summaryQty.textContent = `${totalCount} नग`;

  let itemsHtml = '';
  AppState.cart.forEach(item => {
    itemsHtml += `
      <div style="display: flex; justify-content: space-between; align-items: center; font-size: var(--text-xs);">
        <span><strong>${item.name}</strong> × ${item.quantity}</span>
        <span class="badge-enquiry-pill" style="font-size: 0.68rem;">चौकशीवर</span>
      </div>
    `;
  });

  summaryList.innerHTML = itemsHtml;
}

function validateCheckoutForm() {
  let isValid = true;

  const nameInput = document.getElementById('checkoutName');
  const phoneInput = document.getElementById('checkoutPhone');
  const emailInput = document.getElementById('checkoutEmail');
  const addressInput = document.getElementById('checkoutAddress');
  const cityInput = document.getElementById('checkoutCity');
  const stateInput = document.getElementById('checkoutState');
  const pincodeInput = document.getElementById('checkoutPincode');
  const consentInput = document.getElementById('checkoutConsent');

  document.querySelectorAll('.field-error').forEach(e => e.textContent = '');
  document.querySelectorAll('.form-input').forEach(f => f.classList.remove('is-invalid'));

  // Name Validation
  if (!nameInput.value.trim()) {
    setError(nameInput, 'checkoutNameError', 'कृपया तुमचे पूर्ण नाव प्रविष्ट करा.');
    isValid = false;
  }

  // Phone Validation (10-digit Indian Mobile)
  const phoneVal = phoneInput.value.trim();
  if (!phoneVal || !/^[6-9]\d{9}$/.test(phoneVal)) {
    setError(phoneInput, 'checkoutPhoneError', 'कृपया वैध १० अंकी भारतीय मोबाइल नंबर प्रविष्ट करा.');
    isValid = false;
  }

  // Email Validation (Optional)
  const emailVal = emailInput ? emailInput.value.trim() : '';
  if (emailVal && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailVal)) {
    setError(emailInput, 'checkoutEmailError', 'कृपया वैध ईमेल पत्ता प्रविष्ट करा.');
    isValid = false;
  }

  // Address
  if (!addressInput.value.trim()) {
    setError(addressInput, 'checkoutAddressError', 'कृपया पत्ता प्रविष्ट करा.');
    isValid = false;
  }

  // City
  if (!cityInput.value.trim()) {
    setError(cityInput, 'checkoutCityError', 'कृपया गाव / शहर प्रविष्ट करा.');
    isValid = false;
  }

  // State
  if (!stateInput.value.trim()) {
    setError(stateInput, 'checkoutStateError', 'कृपया राज्य प्रविष्ट करा.');
    isValid = false;
  }

  // Pincode (6-digit)
  const pincodeVal = pincodeInput.value.trim();
  if (!pincodeVal || !/^\d{6}$/.test(pincodeVal)) {
    setError(pincodeInput, 'checkoutPincodeError', 'कृपया ६ अंकी वैध पिनकोड प्रविष्ट करा.');
    isValid = false;
  }

  // Consent
  if (consentInput && !consentInput.checked) {
    const consentErr = document.getElementById('checkoutConsentError');
    if (consentErr) consentErr.textContent = 'कृपया संपर्क साधण्यास संमती द्या.';
    isValid = false;
  }

  return isValid;
}

function setError(inputEl, errorId, message) {
  if (inputEl) inputEl.classList.add('is-invalid');
  const err = document.getElementById(errorId);
  if (err) err.textContent = message;
}

function generateOrderId() {
  const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  return `VAM-${dateStr}-${randomSuffix}`;
}

function handleCheckoutSubmit(e) {
  e.preventDefault();
  if (!validateCheckoutForm()) return;

  const orderData = collectOrderData();
  saveOrder(orderData);
  displayOrderSuccess(orderData);
  
  AppState.cart = [];
  saveCart();
  updateCartBadge();
  closeCheckout();
}

function submitOrderWithWhatsApp() {
  if (!validateCheckoutForm()) return;

  const orderData = collectOrderData();
  saveOrder(orderData);
  
  const waUrl = generateOrderWhatsAppUrl(orderData);
  window.open(waUrl, '_blank');

  displayOrderSuccess(orderData);
  
  AppState.cart = [];
  saveCart();
  updateCartBadge();
  closeCheckout();
}

function collectOrderData() {
  const contactPrefRadio = document.querySelector('input[name="contactPref"]:checked');
  const paymentModeRadio = document.querySelector('input[name="paymentMode"]:checked');

  return {
    orderId: generateOrderId(),
    timestamp: new Date().toISOString(),
    customer: {
      name: document.getElementById('checkoutName').value.trim(),
      phone: document.getElementById('checkoutPhone').value.trim(),
      email: document.getElementById('checkoutEmail').value.trim() || null,
      address: document.getElementById('checkoutAddress').value.trim(),
      city: document.getElementById('checkoutCity').value.trim(),
      district: document.getElementById('checkoutDistrict').value.trim() || 'Ratnagiri',
      state: document.getElementById('checkoutState').value.trim() || 'Maharashtra',
      pincode: document.getElementById('checkoutPincode').value.trim(),
      contactPref: contactPrefRadio ? contactPrefRadio.value : 'WhatsApp',
      notes: document.getElementById('checkoutNotes').value.trim() || 'None'
    },
    paymentMode: paymentModeRadio ? paymentModeRadio.value : 'Pay on Confirmation',
    upiRef: (paymentModeRadio && paymentModeRadio.value === 'UPI Payment' && document.getElementById('checkoutUpiRef')) ? document.getElementById('checkoutUpiRef').value.trim() : null,
    items: [...AppState.cart]
  };
}

function saveOrder(orderData) {
  try {
    const existingOrders = JSON.parse(localStorage.getItem(CONFIG.storageKeys.orders) || '[]');
    existingOrders.push(orderData);
    localStorage.setItem(CONFIG.storageKeys.orders, JSON.stringify(existingOrders));
  } catch (err) {
    console.warn('Order storage error:', err);
  }
}

function displayOrderSuccess(orderData) {
  const successModal = document.getElementById('orderSuccessModalBackdrop');
  const detailsCard = document.getElementById('successDetailsCard');
  const successWaBtn = document.getElementById('successWhatsappBtn');

  if (!successModal || !detailsCard) return;

  const itemsSummary = orderData.items
    .map(i => `• ${i.name} (नग: ${i.quantity})`)
    .join('<br>');

  detailsCard.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--color-border); padding-bottom: 8px;">
      <span style="font-size: var(--text-xs);">ऑर्डर / चौकशी क्रमांक:</span>
      <span class="success-order-num">${orderData.orderId}</span>
    </div>
    <div style="margin-top: 6px;">
      <strong style="font-size: var(--text-xs);">ग्राहक माहिती:</strong>
      <p style="font-size: var(--text-xs); margin-top: 2px; color: var(--color-body);">
        ${orderData.customer.name} | 📞 ${orderData.customer.phone}<br>
        📍 ${orderData.customer.address}, ${orderData.customer.city}, ${orderData.customer.district} - ${orderData.customer.pincode}
      </p>
    </div>
    <div style="margin-top: 6px;">
      <strong style="font-size: var(--text-xs);">मागवलेली उपकरणे:</strong>
      <p style="font-size: var(--text-xs); margin-top: 2px; color: var(--color-forest); font-weight: 700;">
        ${itemsSummary}
      </p>
    </div>
    <div style="margin-top: 4px; font-size: 0.72rem; color: var(--color-muted);">
      पेमेंट पद्धत: <strong>${orderData.paymentMode}</strong> ${orderData.upiRef ? `<span style="background:#EBF4EE;color:#0B4D2A;padding:2px 6px;border-radius:4px;font-weight:700;">UTR: ${orderData.upiRef}</span>` : ''} | संपर्क प्राधान्य: ${orderData.customer.contactPref}
    </div>
  `;

  if (successWaBtn) {
    successWaBtn.href = generateOrderWhatsAppUrl(orderData);
  }

  successModal.classList.add('active');
  successModal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
}

function closeOrderSuccessModal() {
  const successModal = document.getElementById('orderSuccessModalBackdrop');
  if (successModal) {
    successModal.classList.remove('active');
    successModal.setAttribute('aria-hidden', 'true');
  }
  document.body.style.overflow = '';
}

/**
 * ----------------------------------------------------------------------------
 * 13. WHATSAPP DYNAMIC MESSAGE BUILDERS
 * ----------------------------------------------------------------------------
 */
function enquireProductViaWhatsApp(productId) {
  const product = PRODUCT_CATALOG.find(p => p.id === productId);
  if (!product) return;

  const paymentNote = orderData.upiRef 
    ? `पेमेंट पद्धत: UPI Transfer
UTR / Trans Ref: ${orderData.upiRef}` 
    : `पेमेंट पद्धत: ${orderData.paymentMode}`;

  const msg = `नमस्कार Vijayashri Agro Mart,

मी वेबसाइटवरून खालील उपकरणांसाठी ऑर्डर/चौकशी नोंदवली आहे:

ऑर्डर क्र: ${orderData.orderId}
नाव: ${orderData.customer.name}
मोबाइल: ${orderData.customer.phone}
पत्ता: ${orderData.customer.address}, ${orderData.customer.city} (${orderData.customer.pincode})

उपकरणे:
${itemsList}

${paymentNote}

सूचना: ${orderData.customer.notes}

कृपया लवकरात लवकर संपर्क करा.`;
  return `https://wa.me/${CONFIG.whatsappNumber}?text=${encodeURIComponent(msg)}`;
}

/**
 * ----------------------------------------------------------------------------
 * 14. QUICK ENQUIRY FORM & LEGAL MODALS
 * ----------------------------------------------------------------------------
 */
function handleQuickEnquirySubmit(e) {
  e.preventDefault();

  const nameInput = document.getElementById('enquiryName');
  const phoneInput = document.getElementById('enquiryPhone');
  const productInput = document.getElementById('enquiryProduct');
  const msgInput = document.getElementById('enquiryMessage');

  let valid = true;
  document.getElementById('enquiryNameError').textContent = '';
  document.getElementById('enquiryPhoneError').textContent = '';

  if (!nameInput.value.trim()) {
    document.getElementById('enquiryNameError').textContent = 'कृपया नाव प्रविष्ट करा.';
    valid = false;
  }

  const phoneVal = phoneInput.value.trim();
  if (!phoneVal || !/^[6-9]\d{9}$/.test(phoneVal)) {
    document.getElementById('enquiryPhoneError').textContent = 'कृपया वैध १० अंकी मोबाइल नंबर प्रविष्ट करा.';
    valid = false;
  }

  if (!valid) return;

  const msg = `नमस्कार Vijayashri Agro Mart,\n\nमाझी चौकशी:\nनाव: ${nameInput.value.trim()}\nमोबाइल: ${phoneVal}\nउत्पादन: ${productInput.value}\nसंदेश: ${msgInput.value.trim() || 'उत्पादन माहिती व किंमत हवी आहे.'}`;
  const url = `https://wa.me/${CONFIG.whatsappNumber}?text=${encodeURIComponent(msg)}`;

  showToast('चौकशी यशस्वीरीत्या नोंदवली!', 'success');
  nameInput.value = '';
  phoneInput.value = '';
  msgInput.value = '';

  window.open(url, '_blank');
}

function openLegalModal(type) {
  const modalBackdrop = document.getElementById('legalModalBackdrop');
  const modalBody = document.getElementById('legalModalBody');
  if (!modalBackdrop || !modalBody) return;

  if (type === 'privacy') {
    modalBody.innerHTML = `
      <h3 style="color: var(--color-deep-forest); font-size: 1.25rem; font-weight: 800; margin-bottom: var(--space-xs);" id="legalModalTitle">गोपनीयता धोरण (Privacy Policy)</h3>
      <p style="font-size: var(--text-xs); color: var(--color-body); line-height: 1.6;">
        विजयश्री ॲग्रो मार्ट (Vijayashri Agro Mart) ग्राहकांच्या वैयक्तिक माहितीची गोपनीयता राखण्यासाठी कटिबद्ध आहे. 
        वेबसाइटवरील चौकशी व ऑर्डर फॉर्मद्वारे गोळा केलेली माहिती (नाव, फोन नंबर, पत्ता) केवळ कृषी उपकरणांची माहिती देणे, 
        डिलिव्हरी समन्वय आणि ग्राहक सेवा पुरवण्यासाठी वापरली जाते. आम्ही आपली माहिती कोणत्याही त्रयस्थ पक्षाला विकत नाही.
      </p>
    `;
  } else {
    modalBody.innerHTML = `
      <h3 style="color: var(--color-deep-forest); font-size: 1.25rem; font-weight: 800; margin-bottom: var(--space-xs);" id="legalModalTitle">अटी व शर्ती (Terms & Conditions)</h3>
      <p style="font-size: var(--text-xs); color: var(--color-body); line-height: 1.6;">
        १. या वेबसाइटवरील सर्व उत्पादने, ब्रँड्स आणि स्पेसिफिकेशन्स अधिकृत माहिती पत्रकांनुसार दर्शविले आहेत.<br>
        २. उत्पादनांच्या अंतिम किमती, उपलब्धता, वॉरंटी आणि डिलिव्हरी अटी थेट चौकशी व कोटेशन वेळी निश्चित केल्या जातील.<br>
        ३. सर्व ब्रँड नावे (STIHL, Really, ELEMAX, LIGHTON, PELICAN) त्यांच्या संबंधित मालकांच्या अधिकृत मालकीची आहेत.
      </p>
    `;
  }

  modalBackdrop.classList.add('active');
  modalBackdrop.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
}

function closeLegalModal() {
  const modalBackdrop = document.getElementById('legalModalBackdrop');
  if (modalBackdrop) {
    modalBackdrop.classList.remove('active');
    modalBackdrop.setAttribute('aria-hidden', 'true');
  }
  document.body.style.overflow = '';
}

/**
 * ----------------------------------------------------------------------------
 * 15. HEADER SCROLL & SCROLLSPY
 * ----------------------------------------------------------------------------
 */
function initHeaderScrollEffect() {
  const header = document.getElementById('header');
  if (!header) return;

  window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 20);
  }, { passive: true });
}

function initScrollSpy() {
  const sections = ['hero', 'categories', 'products', 'comparison', 'applications', 'why-us', 'about', 'contact'];
  const navLinks = document.querySelectorAll('.nav-link');
  const mobileHome = document.getElementById('mobileNavHome');
  const mobileProducts = document.getElementById('mobileNavProducts');

  window.addEventListener('scroll', () => {
    let current = 'hero';
    const scrollPosition = window.scrollY + 140;

    sections.forEach(secId => {
      const el = document.getElementById(secId);
      if (el && el.offsetTop <= scrollPosition) current = secId;
    });

    navLinks.forEach(link => {
      link.classList.toggle('active', link.getAttribute('href') === `#${current}`);
    });

    if (mobileHome && mobileProducts) {
      mobileHome.classList.toggle('active', current === 'hero');
      mobileProducts.classList.toggle('active', current === 'products' || current === 'categories');
    }
  }, { passive: true });
}

/**
 * ----------------------------------------------------------------------------
 * 16. TOAST NOTIFICATIONS
 * ----------------------------------------------------------------------------
 */
function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'toastOut 200ms forwards';
    setTimeout(() => {
      if (toast.parentElement) toast.parentElement.removeChild(toast);
    }, 200);
  }, 3000);
}
